<?php
$OPT=new stdclass();
$OPT->cerrado=0;
$OPT->actualiza=1;
$OPT->geo=1;
$OPT->https=0;
?>
