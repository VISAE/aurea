<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2022 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.28.2 viernes, 2 de septiembre de 2022
*/
$btabla = 'unae40historialcambdoc';
$borigen = 'unae40idorigen';
$bidarchivo = 'unae40idarchivo';
$bidreg = 'unae40id';
$bunico = true;
?>