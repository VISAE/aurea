<?php
$APP=new stdclass();
$APP->idsistema=3072;
$APP->tipo_doc='CC';
$APP->idserver=4;
$APP->tiempolimite=120;
$APP->utf8=0;
$APP->rutacomun='../ulib/';
$APP->rutaconfig='';
$APP->urltablero='miscursos.php';

$APP->dbhost='172.21.0.80';
$APP->dbpuerto='30001';
$APP->dbname='unadsys';
$APP->dbuser='desarrollo';
$APP->dbpass='aLqm2ejk#';
?>
