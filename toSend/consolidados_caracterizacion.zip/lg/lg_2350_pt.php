<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2018 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.21.0 jueves, 21 de junio de 2018
---
--- Cambios 21 de mayo de 2020
--- 1. Agrega Etiquetas escuela y programa
--- Omar Augusto Bautista Mora - UNAD - 2020
--- omar.bautista@unad.edu.co
*/
$ETI['app_nombre']='APP';
$ETI['grupo_nombre']='Grupo';
$ETI['titulo']='Consolidado';
$ETI['titulo_sector2']='Consolidado';
$ETI['titulo_2350']='Consolidado';
$ETI['sigla_2350']='Consolidado';
$ETI['lnk_cargar']='Editar';
$ETI['core50idperaca']='Peraca';
$ETI['core50idzona']='Zona';
$ETI['core50idcentro']='Centro';
$ETI['core50idescuela']='Escuela';
$ETI['core50idprograma']='Programa';

$ERR['core50idperaca']='&Eacute; necess&aacute;rio o dado Peraca';
$ERR['core50idzona']='&Eacute; necess&aacute;rio o dado Zona';
$ERR['core50idcentro']='&Eacute; necess&aacute;rio o dado Centro';
?>
