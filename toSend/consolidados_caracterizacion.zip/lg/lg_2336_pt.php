<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.8 Wednesday, October 30, 2019
---
--- Cambios 21 de mayo de 2020
--- 1. Agrega Etiquetas escuela y programa
--- Omar Augusto Bautista Mora - UNAD - 2020
--- omar.bautista@unad.edu.co
*/
$ETI['app_nombre']='APP';
$ETI['grupo_nombre']='Grupo';
$ETI['titulo']='Consolidado de acompanamientos';
$ETI['titulo_sector2']='Consolidado de acompanamientos';
$ETI['titulo_2336']='Consolidado de acompanamientos';
$ETI['sigla_2336']='Consolidado de acompanamientos';
$ETI['lnk_cargar']='Editar';
$ETI['cara33idperaca']='Peraca';
$ETI['cara33idzona']='Zona';
$ETI['cara33idcentro']='Centro';
$ETI['cara33idescuela']='Escuela';
$ETI['cara33idprograma']='Programa';
$ETI['cara33tipo']='Tipo';
$ETI['cara33poblacion']='Poblacion';

$ERR['cara33idperaca']='&Eacute; necess&aacute;rio o dado '.$ETI['cara33idperaca'];
$ERR['cara33idzona']='&Eacute; necess&aacute;rio o dado '.$ETI['cara33idzona'];
$ERR['cara33idcentro']='&Eacute; necess&aacute;rio o dado '.$ETI['cara33idcentro'];
$ERR['cara33tipo']='&Eacute; necess&aacute;rio o dado '.$ETI['cara33tipo'];
$ERR['cara33poblacion']='&Eacute; necess&aacute;rio o dado '.$ETI['cara33poblacion'];
$acara33tipo=array('', '');
$icara33tipo=0;
$acara33poblacion=array('', '');
$icara33poblacion=0;
?>
