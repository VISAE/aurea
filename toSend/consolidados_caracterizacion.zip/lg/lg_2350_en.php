<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2018 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Model Version 2.21.0 jueves, 21 de junio de 2018
---
--- Cambios 21 de mayo de 2020
--- 1. Agrega Etiquetas escuela y programa
--- Omar Augusto Bautista Mora - UNAD - 2020
--- omar.bautista@unad.edu.co
*/
$ETI['app_nombre']='APP';
$ETI['grupo_nombre']='Grupo';
$ETI['titulo']='Consolidado';
$ETI['titulo_sector2']='Consolidado';
$ETI['titulo_2350']='Consolidado';
$ETI['sigla_2350']='Consolidado';
$ETI['lnk_cargar']='Edit';
$ETI['core50idperaca']='Peraca';
$ETI['core50idzona']='Zona';
$ETI['core50idcentro']='Centro';
$ETI['core50idescuela']='Escuela';
$ETI['core50idprograma']='Programa';

$ERR['core50idperaca']='Is necessary the data Peraca';
$ERR['core50idzona']='Is necessary the data Zona';
$ERR['core50idcentro']='Is necessary the data Centro';
?>
