<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.22.6d miércoles, 23 de enero de 2019
---
--- Cambios 21 de mayo de 2020
--- 1. Agrega Etiquetas escuela y programa
--- Omar Augusto Bautista Mora - UNAD - 2020
--- omar.bautista@unad.edu.co
*/
$ETI['app_nombre']='APP';
$ETI['grupo_nombre']='Grupo';
$ETI['titulo']='Necesidades especiales';
$ETI['titulo_sector2']='Necesidades especiales';
$ETI['titulo_2349']='Necesidades especiales';
$ETI['sigla_2349']='Necesidades especiales';
$ETI['lnk_cargar']='Editar';
$ETI['cara49idperaca']='Peraca';
$ETI['cara49idzona']='Zona';
$ETI['cara49idcentro']='Centro';
$ETI['cara49idescuela']='Escuela';
$ETI['cara49idprograma']='Programa';
$ETI['cara49tipopoblacion']='Tipopoblacion';

$ERR['cara49idperaca']='&Eacute; necess&aacute;rio o dado '.$ETI['cara49idperaca'];
$ERR['cara49idzona']='&Eacute; necess&aacute;rio o dado '.$ETI['cara49idzona'];
$ERR['cara49idcentro']='&Eacute; necess&aacute;rio o dado '.$ETI['cara49idcentro'];
$ERR['cara49tipopoblacion']='&Eacute; necess&aacute;rio o dado '.$ETI['cara49tipopoblacion'];
$acara49tipopoblacion=array('', '');
$icara49tipopoblacion=0;
?>
